# x16s_hash
Python module for the x16s hash function

## Prerequisites

```
sudo apt-get install python-dev
```

## Installation

To install this module, clone this repository and run:

```
pip install x16s-hash
```
